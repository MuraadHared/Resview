This project is for CS2132.
1. In order to run this, please install NodeJS from: https://nodejs.org/
2. Open command line and go to this directory
3. run "node server.js" in command line without quotations
4. go to localhost:3001 to see the website

Team Members:
Sarmad Hashmi (7249729)
Salman Rana (7395721)
Muraad Hared (7417789)