-- Sarmad's RatingItems -- 


INSERT INTO RatingItem
VALUES
(3, 1, '2014-11-23 16:19:52', 2.7, 'Hated it.');
INSERT INTO RatingItem
VALUES
(6, 2, '2014-03-20 22:27:32', 1.2, 'Not impressed at all.');
INSERT INTO RatingItem
VALUES
(2, 3, '2015-03-03 17:21:22', 3.7, 'Average.');
INSERT INTO RatingItem
VALUES
(12, 4, '2015-03-23 09:36:19', 4.7, 'Excellent.');
INSERT INTO RatingItem
VALUES
(4, 5, '2014-02-17 12:09:55', 4.2, 'Very impressed.');
INSERT INTO RatingItem
VALUES
(9, 6, '2013-08-10 13:22:59', 3.4, 'Required more flavour.');
INSERT INTO RatingItem
VALUES
(10, 7, '2014-10-20 19:45:29', 4.3, 'Almost perfect.');
INSERT INTO RatingItem
VALUES
(2, 8, '2014-09-09 19:57:10', 5.0, 'Masterpiece.');
INSERT INTO RatingItem
VALUES
(7, 9, '2015-03-07 19:22:09', 3.2, 'Not amazing. Not bad.');
INSERT INTO RatingItem
VALUES
(8, 10, '2012-12-09 23:22:08', 2.9, 'Alright.');
INSERT INTO RatingItem
VALUES
(14, 11, '2014-12-22 02:39:24', 2.5, 'Try harder next time.');
INSERT INTO RatingItem
VALUES
(14, 12, '2014-12-15 12:05:19', 3.8, 'Almost perfection.');
INSERT INTO RatingItem
VALUES
(13, 13, '2015-03-10 18:26:14', 1.6, 'Left a bad taste in my mouth.');
INSERT INTO RatingItem
VALUES
(3, 14, '2015-02-05 17:37:34', 2.1, 'Not true food.');
INSERT INTO RatingItem
VALUES
(1, 15, '2015-02-10 23:57:04', 2.9, 'Needed more spices.');

-- Muraad's RatingItems -- 



INSERT INTO RatingItem
VALUES
('2','16','2014-06-20 19:45:10',2,'The cheese is soft but you can taste the fat in every bite');

INSERT INTO RatingItem
VALUES
('4','17','2013-04-02 03:05:10',3.6,'Good salad if your on a diet');

INSERT INTO RatingItem
VALUES
('6','18','2014-07-11 05:00:10',2,'Way too sweet, needed to water it down');



INSERT INTO RatingItem
VALUES
('8','19','2014-11-26 18:05:10',3,'Pretty expensive for an appetizer');

INSERT INTO RatingItem
VALUES
('10','20','2015-01-12 01:22:10',3.6,'Nice mixture of raisins nuts and rice');

INSERT INTO RatingItem
VALUES
('12','21','2015-04-02 22:03:10',4.2,'Amazing dish');


INSERT INTO RatingItem
VALUES
('14','22','2014-08-20 15:36:10',2,'way too spicy, the hot peppers were everywhere');

INSERT INTO RatingItem
VALUES
('1','23','2014-12-25 02:22:10',5,'So much food for a resonable price');

INSERT INTO RatingItem
VALUES
('3','24','2014-09-20 14:45:10',5,'Soft and delicious brownie!');


INSERT INTO RatingItem
VALUES
('5','25','2014-11-16 05:33:10',3,'Best garlic potatoes but they are a bit expensive');

INSERT INTO RatingItem
VALUES
('7','26','2014-12-20 16:00:10',5,'Best chicken shawarma plate in town');

INSERT INTO RatingItem
VALUES
('9','27','2013-01-02 12:10:10',1,'My sandwich was falling apart the moment I grabbed it out of the Bag');


INSERT INTO RatingItem
VALUES
('11','28','2015-02-02 03:21:11',2.5,'Meatballs were dry');

INSERT INTO RatingItem
VALUES
('13','29','2014-10-26 09:45:10',4.3,'Nice balance of different flavors');

INSERT INTO RatingItem
VALUES
('15','30','2014-04-20 18:56:10',3.5,'The root beer taste is a bit too strong for the ice cream mix');


-- Salman's RatingItems --

INSERT INTO RatingItem
VALUES
('1','31','2012-12-25 09:42:04', 2.2 ,'Tasted burnt, apparently it is supposed to take burnt.');


INSERT INTO RatingItem
VALUES
('15','31','2013-09-15 16:12:09', 2.0 ,'Smells weird!');

INSERT INTO RatingItem
VALUES
('13','31','2014-07-07 02:25:14', 2.7 ,'It was dry and tasteless.');


INSERT INTO RatingItem
VALUES
('12','32','2015-04-12 07:25:14', 4.1 ,'AMAZING SHRIMP!!!!!');


INSERT INTO RatingItem
VALUES
('9','33','2013-01-12 20:12:57', 1.2 ,'AVOID! The mushrooms lacked flavor.');


INSERT INTO RatingItem
VALUES
('1','34','2013-06-13 12:01:27', 3.2,'Taste greate, but they were too oily');


INSERT INTO RatingItem
VALUES
('15','35','2015-07-13 20:26:11', 4.5 ,'A really good dessert. Highly reccomend it!');


INSERT INTO RatingItem
VALUES
('13','36','2014-07-05 23:38:19', 4.2 ,'Love the taste of basil in the rice');

INSERT INTO RatingItem
VALUES
('12','36','2015-04-12 06:21:52', 3.1 ,'I would not reccomend this, the sauce is way too salty');

INSERT INTO RatingItem
VALUES
('1','36','2013-06-13 12:03:37', 3.2 ,'Not a fan of the cashew nuts they mix in the rice');


INSERT INTO RatingItem
VALUES
('6','37','2014-05-19 19:35:10', 3.1,'Good pizza, but nothing special.');


INSERT INTO RatingItem
VALUES
('9','38','2013-09-15 09:15:15',4.9,'Highly recomend this soup!');

INSERT INTO RatingItem
VALUES
('7','38','2015-07-07 07:18:25',4.1,'Tastes great!');

INSERT INTO RatingItem
VALUES
('3','38','2015-04-12 21:20:10',4.2,'Really good vegetable soup.');


INSERT INTO RatingItem
VALUES
('1','39','2012-12-29 03:45:18',4.9,'Just WOW! Greate tasteing fettuccine.');


INSERT INTO RatingItem
VALUES
('11','40','2013-03-19 10:21:12', 3.9,'Nicely grilled and seasoned');


INSERT INTO RatingItem
VALUES
('8','41','2015-04-12 08:01:43', 2.1,'Not the best tasteing taco I have had');

INSERT INTO RatingItem
VALUES
('6','42','2014-07-07 02:26:34',4.9,'I would really recommned this if you are looking for some boneless steak.');

INSERT INTO RatingItem
VALUES
('8','42','2015-04-12 07:20:56',2.4,'Too spicy for my liking');

INSERT INTO RatingItem
VALUES
('14','42','2014-10-13 15:45:11',1.4,'I found it to be overcooked and too chewy');

INSERT INTO RatingItem
VALUES
('5','43','2014-05-01 19:20:19',0.9,'WORST Kabobs I have ever tasted! Avoid at all costs.');

INSERT INTO RatingItem
VALUES
('14','44','2014-09-15 16:22:01',4.6,'YUM YUM YUM!');

INSERT INTO RatingItem
VALUES
('9','44','2012-12-29 17:40:29',4.9,'Greate taste, highly reccomend this as a starter');

INSERT INTO RatingItem
VALUES
('4','44','2013-01-12 14:51:41',4.2,'Good appetizer');

INSERT INTO RatingItem
VALUES
('2','45','2015-01-09 03:40:01', 2.1,'Too sweet and a waste of money.');


