--******************************SOCA KITCHEN & PUB******************************** -- 

INSERT INTO Rating
VALUES
('11','6','2013-07-22 06:12:03','Food took a long time but was worth the wait',4,4.2,3.6,3.6);

INSERT INTO Rating
VALUES
('14','6','2014-01-19 18:46:16','The chicken was dry and the waiter never refilled my water',1.3,2.9,1.6,1.8);

INSERT INTO Rating
VALUES
('6','6','2014-11-20 05:54:43','The food is great, price is great, everyone go to SOCAs!',4.8,4.9,3.9,4);

INSERT INTO Rating
VALUES
('8','6','2015-01-02 07:40:54','Food was good but a bit too expensive',2.6,4.2,4.0,3.2);

INSERT INTO Rating
VALUES
('13','6','2015-02-01 15:42:09','Affordable place to take a date with decent food',4.3,3.4,3.3,3.9);

INSERT INTO Rating
VALUES
('12','6','2015-01-20 11:53:56','Great prices but the takes 20 minutes to receive your food.',2.4,4.2,3.9,5);

INSERT INTO Rating
VALUES
('1','6','2014-12-30 19:01:28','Bad experience and the food was cold',2.4,1,1,1);

INSERT INTO Rating
VALUES
('3','6','2013-06-03 19:18:19','The service was okay, but it could have been better',3.1,3.5,3.3,3);

--MenuItems 

INSERT INTO MenuItem
VALUES
(DEFAULT,'6','CARLES ROQUEFORT','Starter','Food','French, soft, and unpasteurized cheese', 5);

INSERT INTO MenuItem
VALUES
(DEFAULT,'6','ROASTED MUSHROOM SALAD','Main','Food','Enjoy a tasty salad topped with roasted mushrooms, black garlic, and white truffle', 15);

INSERT INTO MenuItem
VALUES
(DEFAULT,'6','STRATUS, MOSAIC, NIAGARA ON THE LAKE','Dessert','Beverage','DESSERT IN A GLASS', 9.17);


--Rating for MenuItems

INSERT INTO RatingItem
VALUES
('2','16','2014-06-20 19:45:10',2,'The cheese is soft but you can taste the fat in every bite');

INSERT INTO RatingItem
VALUES
('4','17','2013-04-02 03:05:10',3.6,'Good salad if your on a diet');

INSERT INTO RatingItem
VALUES
('6','18','2014-07-11 05:00:10',2,'Way too sweet, needed to water it down');

-- ************************************HAVELI************************************* --

INSERT INTO Rating
VALUES
('2','7','2014-12-05 09:52:03','Too expensive for a small amount of food',2,2.2,3.6,3.6);

INSERT INTO Rating
VALUES
('4','7','2014-11-19 15:10:16','The waiters were rude but the food was nice',3.3,3.9,1.6,1.8);

INSERT INTO Rating
VALUES
('6','7','2014-05-25 08:04:43','Your treated with respect while you eat some cheap tasty food',4.8,4.9,3.9,4.2);

INSERT INTO Rating
VALUES
('8','7','2013-01-22 07:00:54','Expensive but nowadays all restaurants are. Food was acceptable',2.6,4.2,4.0,4.2);

INSERT INTO Rating
VALUES
('10','7','2015-03-13 22:42:09','Walked out of the restaurant angry from the service',2,2,1,1);

INSERT INTO Rating
VALUES
('12','7','2015-03-16 14:53:56','I saw my food made but the waiter took an extra 10 minutes to answer a phone call',2,2,1,1);

INSERT INTO Rating
VALUES
('14','7','2014-09-04 10:01:28','Thought i would give this place a chance but im definitely not coming back',1,1,1,1);

INSERT INTO Rating
VALUES
('1','7','2013-11-13 12:08:19','If you like Indian food this is the place to be',4.1,4.5,4.3,3);

--MenuItems 

INSERT INTO MenuItem
VALUES
(DEFAULT,'7','Aloo Tiki Chaat','Starter','Food','Two potato patties topped with curried chickpeas, yogurt, and a delicious tamarind sauce', 6.50);

INSERT INTO MenuItem
VALUES
(DEFAULT,'7','Shahjehani Biryani','Main','Food','An ornate rice dish cooked with boneless lamb, nuts, raisins, and flavored with saffron', 16.25);

INSERT INTO MenuItem
VALUES
(DEFAULT,'7','Patiala Pulao','Main','Food','An elegant Punjabi preparation, Basmati rice cooked with green peas, garnished with mushrooms.', 5.50);


--Rating for MenuItems

INSERT INTO RatingItem
VALUES
('8','19','2014-11-26 18:05:10',3,'Pretty expensive for an appetizer');

INSERT INTO RatingItem
VALUES
('10','20','2015-01-12 01:22:10',3.6,'Nice mixture of raisins nuts and rice');

INSERT INTO RatingItem
VALUES
('12','21','2015-04-02 22:03:10',4.2,'Amazing dish');

-- **********************************MUCHO BURRITO******************************** --

INSERT INTO Rating
VALUES
('3','8','2013-01-25 16:22:03','Best burritos in town!',4,4.6,4.6,4.6);

INSERT INTO Rating
VALUES
('5','8','2014-04-02 22:01:16','Takes a long time for the staff to make over 5 burritos so it isnt the best place for large groups',3.3,3.9,3.6,3.8);

INSERT INTO Rating
VALUES
('7','8','2015-01-20 15:58:43','I made it a weekly routine to get my burritos from Mucho Burrito! Try it!',4.8,4.9,4.9,4);

INSERT INTO Rating
VALUES
('9','8','2013-01-24 04:40:54','Hate that they charge extra for specific toppings, other than that the food is good',2.6,4.2,4.0,4.2);

INSERT INTO Rating
VALUES
('11','8','2015-02-01 19:42:09','Never thought i would fall in love with Mexican food but i did!',4.3,4.4,4.3,4.9);

INSERT INTO Rating
VALUES
('13','8','2015-03-10 12:53:56','Nice quiet place to grab lunch with a few friends',4.4,4.2,3.9,5);

INSERT INTO Rating
VALUES
('15','8','2014-10-03 09:01:28','My burrito was too soggy, was not like the ones my mom makes at home. True mexican people would be disappointed',2.4,2,2,2);

INSERT INTO Rating
VALUES
('2','8','2014-06-13 05:18:29','6 bucks for a small buritto?? I can buy the ingrediants for ten burritos with that money',1.1,3.5,3.3,3);

--MenuItems 

INSERT INTO MenuItem
VALUES
(DEFAULT,'8','Nachos','Starter','Food','Fresh tortilla chips and layer of two melted cheeses, toppings and five types of salsa and sour cream', 8.95);

INSERT INTO MenuItem
VALUES
(DEFAULT,'8','Salad Bowl','Main','Food','Shell bowl with cold crisp Romaine lettuce, with piping hot fillings, all of your favourite toppings, fresh salsa and cheese.', 13.95);

INSERT INTO MenuItem
VALUES
(DEFAULT,'8','Hot Fudge Mexican Brownie','Dessert','Food','A spicy Mexican chocolate brownie (the heat is bearable!)', 7.45);


--Rating for MenuItems

INSERT INTO RatingItem
VALUES
('14','22','2014-08-20 15:36:10',2,'way too spicy, the hot peppers were everywhere');

INSERT INTO RatingItem
VALUES
('1','23','2014-12-25 02:22:10',5,'So much food for a resonable price');

INSERT INTO RatingItem
VALUES
('3','24','2014-09-20 14:45:10',5,'Soft and delicious brownie!');

-- *********************************SHAWARMA PRINCE****************************** -- 

INSERT INTO Rating
VALUES
('4','9','2013-06-15 01:12:53','Great place to take the family',4,4,4,4);

INSERT INTO Rating
VALUES
('6','9','2014-11-12 03:36:06','The white rice is always fresh! The shawarma plate is the best option',4.3,4.9,3.6,4.8);

INSERT INTO Rating
VALUES
('8','9','2014-02-20 03:44:43','The garlic potatoes are amazing but expensive',2.8,4.9,3.9,4);

INSERT INTO Rating
VALUES
('10','9','2014-03-05 18:10:54','The pickles were sour, seems like everytime i go late the food quality is poor',3.6,2.2,3.0,3.2);

INSERT INTO Rating
VALUES
('12','9','2015-04-01 11:42:09','Took way too long to get my food',3,3,1,1);

INSERT INTO Rating
VALUES
('14','9','2014-10-00 20:53:56','I personally prefer Shawarma Gloucester location, the other two are always packed.',3,4.2,3.9,3);

INSERT INTO Rating
VALUES
('1','9','2014-11-10 19:01:28','Multiple locations so give it a try!',4.4,4,4,4);

INSERT INTO Rating
VALUES
('3','9','2013-06-11 12:22:03','The shawarma plate is amazing',4.1,4.5,4.3,4);

--MenuItems 

INSERT INTO MenuItem
VALUES
(DEFAULT,'9','Garlic Potatoes','Starter','Food','Crisp potatoes topped with garlic sauce',4.95 );

INSERT INTO MenuItem
VALUES
(DEFAULT,'9','Family Shawarma Plate','Main','Food','Two trays filled with chicken, beef,garlic potatoes,rice, and tons of veggies', 36.99);

INSERT INTO MenuItem
VALUES
(DEFAULT,'9','Chicken Shawarma Sandwich','Main','Food','Chicken, garlic, hummus sauce, and veggies wrapped in a crispy pita', 4.99);


--Rating for MenuItems

INSERT INTO RatingItem
VALUES
('5','25','2014-11-16 05:33:10',3,'Best garlic potatoes but they are a bit expensive');

INSERT INTO RatingItem
VALUES
('7','26','2014-12-20 16:00:10',5,'Best chicken shawarma plate in town');

INSERT INTO RatingItem
VALUES
('9','27','2013-01-02 12:10:10',1,'My sandwich was falling apart the moment I grabbed it out of the Bag');

-- *****************************EAST SIDE MARIO'S*********************************--

INSERT INTO Rating
VALUES
('5','10','2013-12-05 10:12:03','Alfredo sauce was too salty',2,2,3,3);

INSERT INTO Rating
VALUES
('7','10','2015-01-01 23:00:16','So much ragu sauce in my pasta',3.3,1.9,3.6,3.8);

INSERT INTO Rating
VALUES
('9','10','2014-11-20 10:54:43','The waiter took way too long to bring me my food',4.8,4.9,1.9,1);

INSERT INTO Rating
VALUES
('11','10','2015-03-02 14:00:54','The service was great but the food could have been better',2.6,2.2,4.0,4.2);

INSERT INTO Rating
VALUES
('13','10','2014-06-11 05:42:09','Best pasta ever!!',4.3,4.4,3.3,3.9);

INSERT INTO Rating
VALUES
('15','10','2014-04-20 01:53:56','You need to give East Side Marios a chance, you will love it',4,4,4,4);

INSERT INTO Rating
VALUES
('1','10','2013-02-03 12:01:58','Everything about this place is perfect, the food, the prices, the staff, everything!',5,5,5,5);

INSERT INTO Rating
VALUES
('3','10','2013-10-05 07:25:39','Disappointed in the service after all the good reviews i read about East Side Marios',3.1,3.5,2.3,2);

--MenuItems 

INSERT INTO MenuItem
VALUES
(DEFAULT,'10','Spaghettini and Meatballs','Main','Food','First we simmer our famous meatballs in Napolitana sauce. Then we pile them on long and thin spaghettini noodles. How about some shredded Parm?', 13.99);

INSERT INTO MenuItem
VALUES
(DEFAULT,'10','Baked Penne Alfredo','Main','Food','Penne, broccoli, Alfredo sauce and mozzarella become best friends when they are baked together to perfection. Served with our fresh bruschetta',13.99 );

INSERT INTO MenuItem
VALUES
(DEFAULT,'10','Root Beer Float','Dessert','Beverage','Frothy treat made with vanilla ice cream and Barqs Root Beer', 3 );


--Rating for MenuItems

INSERT INTO RatingItem
VALUES
('11','28','2015-02-02 03:21:11',2.5,'Meatballs were dry');

INSERT INTO RatingItem
VALUES
('13','29','2014-10-26 09:45:10',4.3,'Nice balance of different flavors');

INSERT INTO RatingItem
VALUES
('15','30','2014-04-20 18:56:10',3.5,'The root beer taste is a bit too strong for the ice cream mix');